declare module 'diff';
